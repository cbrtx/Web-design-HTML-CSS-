# урок 7

A Pen created on CodePen.

Original URL: [https://codepen.io/elvira_a/pen/OPMMjqb](https://codepen.io/elvira_a/pen/OPMMjqb).

